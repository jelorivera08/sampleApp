## Instructions on how to start app
> npm install
> npm start
