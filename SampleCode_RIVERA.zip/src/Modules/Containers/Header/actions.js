const addATodo = () => ({
  type: "ADD_A_TODO"
});

const action = {
  addATodo
};

export default action;
